#!/bin/bash
# Installa (o aggiorna) EasyPTT Talk Server come servizio su Ubuntu/Debian.
# Uso:  sudo bash installa.sh                    (installa o aggiorna, i dati restano)
#       sudo bash installa.sh backup.eptbak      (installa e ripristina un backup della console;
#                                                 chiede la password del backup. Va bene anche un .zip
#                                                 delle versioni precedenti)
set -e
[ "$(id -u)" = 0 ] || { echo "Esegui con: sudo bash installa.sh"; exit 1; }
BK=""; [ -n "$1" ] && BK="$(readlink -f "$1")"
cd "$(dirname "$0")"
DIR=/opt/easyptt-talk
ETC=/etc/easyptt-talk
KEY=$ETC/chiave.key
id easyptt >/dev/null 2>&1 || useradd --system --home "$DIR" --shell /usr/sbin/nologin easyptt
mkdir -p "$DIR/dati" "$ETC"
chmod 700 "$ETC"
systemctl stop easyptt-talk 2>/dev/null || true
install -m 755 easyptt-talk-server "$DIR/easyptt-talk-server"
# script e istruzioni accanto al programma: applica-aggiornamento.sh serve all'aggiornamento
# dalla console (console > Server), gli altri per rilanciarli da $DIR
if [ "$(pwd -P)" != "$(readlink -f "$DIR")" ]; then
  for f in installa.sh certificato.sh sicurezza.sh LEGGIMI.txt applica-aggiornamento.sh; do
    [ -f "$f" ] && install -m 755 "$f" "$DIR/$f"
  done
  [ -f "$DIR/LEGGIMI.txt" ] && chmod 644 "$DIR/LEGGIMI.txt"
fi

# Chiave di cifratura dei dati (AES-256): fuori dalla cartella dati, leggibile solo da root.
# systemd la passa al servizio all'avvio. Non e' nei backup giornalieri: e' nel backup cifrato della console.
if [ ! -s "$KEY" ]; then
  if [ -s "$DIR/dati/chiave.key" ]; then mv "$DIR/dati/chiave.key" "$KEY"
  else head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' > "$KEY"; echo >> "$KEY"; fi
fi
chmod 600 "$KEY"; chown root:root "$KEY"

# Ripristino di un backup scaricato dalla console
if [ -n "$BK" ]; then
  [ -f "$BK" ] || { echo "File di backup non trovato: $1"; exit 1; }
  if [ "$(head -c 4 "$BK")" = "EPTB" ] && [ -z "$EPT_PASS" ]; then
    read -rsp "Password del backup: " EPT_PASS; echo
  fi
  EPT_PASS="$EPT_PASS" "$DIR/easyptt-talk-server" -ripristina "$BK" -dati "$DIR/dati" -chiave "$KEY"
  chmod 600 "$KEY"; chown root:root "$KEY"
fi
# programma e script di root, solo i dati del servizio: un processo "easyptt" non puo' sostituire
# cio' che systemd avvia come root (verifica e applicazione degli aggiornamenti)
chown root:root "$DIR"
chown -R easyptt:easyptt "$DIR/dati"
for f in easyptt-talk-server easyptt-talk-server.old; do [ -f "$DIR/$f" ] && chown root:root "$DIR/$f"; done
# gli script girano come root: restano di root
for f in installa.sh certificato.sh sicurezza.sh LEGGIMI.txt applica-aggiornamento.sh; do
  [ -f "$DIR/$f" ] && chown root:root "$DIR/$f"
done
chmod 700 "$DIR/dati"
# installazione a mano: un aggiornamento scaricato dalla console e non ancora applicato non serve piu'
rm -f "$DIR/dati/aggiornamento/pronto" "$DIR/dati/aggiornamento/pacchetto.tar.gz" "$DIR/dati/aggiornamento/pacchetto.sig" "$DIR/dati/aggiornamento/provando"
touch "$ETC/opzioni"   # opzioni aggiuntive (es. EPT_OPZIONI="-https :8443,:443", scritte da certificato.sh)

unit() { # $1 = rinforzata (1) o minima (0)
cat > /etc/systemd/system/easyptt-talk.service <<U
[Unit]
Description=EasyPTT Talk Server
After=network-online.target
Wants=network-online.target

[Service]
User=easyptt
Group=easyptt
WorkingDirectory=$DIR
EnvironmentFile=-$ETC/opzioni
# prima dell'avvio, come root fuori dall'isolamento (+): installa l'aggiornamento scaricato
# dalla console, con backup dei dati e ritorno alla versione precedente se la nuova non parte
# (-: se lo script manca il servizio parte lo stesso)
ExecStartPre=-+$DIR/applica-aggiornamento.sh
TimeoutStartSec=600
# 8443 cifrata, aperta a Internet. 8080 non cifrata: solo dal server stesso.
ExecStart=$DIR/easyptt-talk-server -https :8443 -http 127.0.0.1:8080 -dati $DIR/dati $KEYARG \$EPT_OPZIONI
Restart=always
RestartSec=3
LimitNOFILE=65536
UMask=0077
NoNewPrivileges=true
# porte sotto 1024 (443 col certificato del dominio) senza essere root
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
U
if [ "$1" = 1 ]; then
cat >> /etc/systemd/system/easyptt-talk.service <<U
LoadCredential=chiave:$KEY
# isolamento: il programma scrive solo nella sua cartella dati e non vede il resto del sistema
ProtectSystem=strict
ReadWritePaths=$DIR/dati
ProtectHome=true
PrivateTmp=true
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectKernelLogs=true
ProtectControlGroups=true
ProtectClock=true
ProtectHostname=true
RestrictNamespaces=true
RestrictRealtime=true
RestrictSUIDSGID=true
LockPersonality=true
MemoryDenyWriteExecute=true
RemoveIPC=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX AF_NETLINK
SystemCallArchitectures=native
SystemCallFilter=@system-service
SystemCallErrorNumber=EPERM
U
else
cat >> /etc/systemd/system/easyptt-talk.service <<U
ProtectSystem=full
ProtectHome=true
PrivateTmp=true
U
fi
cat >> /etc/systemd/system/easyptt-talk.service <<U

[Install]
WantedBy=multi-user.target
U
}

KEYARG=""
unit 1
systemctl daemon-reload
systemctl enable easyptt-talk >/dev/null 2>&1
systemctl restart easyptt-talk
sleep 3
if ! systemctl is-active --quiet easyptt-talk; then
  if journalctl -u easyptt-talk -n 30 --no-pager | grep -q "chiave di cifratura"; then
    echo; echo "ERRORE: la chiave di cifratura non corrisponde ai dati."
    echo "Ripristina la chiave giusta in $KEY (e' anche nel backup cifrato della console) e rilancia."
    journalctl -u easyptt-talk -n 5 --no-pager | tail -3
    exit 1
  fi
  # sistemi con systemd vecchio: unita' semplice, chiave in una copia leggibile solo dal servizio
  echo "Isolamento completo non supportato da questo sistema: uso la configurazione semplice."
  install -o easyptt -g easyptt -m 400 "$KEY" "$DIR/chiave.key"
  KEYARG="-chiave $DIR/chiave.key"
  unit 0
  systemctl daemon-reload
  systemctl restart easyptt-talk
  sleep 3
fi

# 8443 console e radio; 8090/1883/1935 droni DJI (pagina per DJI Pilot 2, telemetria, video):
# il server le usa solo se almeno un'organizzazione ha la funzione "Droni DJI"
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  for p in 8443 8090 1883 1935; do ufw allow $p/tcp >/dev/null; done
fi
# backup giornaliero dei dati (conserva 14 giorni; senza l'audio delle registrazioni, che resta in dati/registro).
# I dati sensibili sono cifrati: la chiave NON e' in questi archivi.
cat > /etc/cron.daily/easyptt-talk-backup <<'B'
#!/bin/sh
mkdir -p /var/backups/easyptt-talk
chmod 700 /var/backups/easyptt-talk
tar czf /var/backups/easyptt-talk/dati-$(date +%F).tar.gz --exclude='*.ept' --exclude='chiave.key' -C /opt/easyptt-talk dati
chmod 600 /var/backups/easyptt-talk/dati-*.tar.gz
find /var/backups/easyptt-talk -name 'dati-*.tar.gz' -mtime +14 -delete
B
chmod 755 /etc/cron.daily/easyptt-talk-backup
echo
systemctl --no-pager --lines=0 status easyptt-talk | head -4
echo
IP=$(hostname -I | awk '{print $1}')
if [ -s "$ETC/dominio" ]; then
  echo "Console:  https://$(cat $ETC/dominio)        Centrale: https://$(cat $ETC/dominio)/centrale"
fi
echo "Console:  https://$IP:8443   (con l'indirizzo IP il browser mostra un avviso sul certificato)"
journalctl -u easyptt-talk --no-pager -n 40 | grep -E "Codice di configurazione|Impronta" -A1 | sed 's/^.*easyptt-talk-server\[[0-9]*\]: //' || true
echo
echo "Comandi utili:"
echo "  stato:    systemctl status easyptt-talk"
echo "  log:      journalctl -u easyptt-talk -f      (anche $DIR/dati/server.log)"
echo "  riavvio:  systemctl restart easyptt-talk"
echo "  certificato valido per un nome di dominio:  sudo bash certificato.sh talk.tuodominio.it"
