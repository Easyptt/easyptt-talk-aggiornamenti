#!/bin/bash
# Applica l'aggiornamento del server scaricato dalla console (console > Server > Aggiorna ora).
# Lo esegue systemd come root prima di ogni avvio del servizio (ExecStartPre=+...).
# Non esce mai con errore: il servizio deve partire comunque. I messaggi vanno nel journal.
#
#  - dati/aggiornamento/pronto + pacchetto.tar.gz + pacchetto.sig: verifica la firma con il
#    programma attuale, backup dei dati, installa la versione nuova (la precedente resta in
#    easyptt-talk-server.old) e scrive "provando".
#  - dati/aggiornamento/provando: la versione nuova non ha ancora confermato di funzionare
#    (lo fa dopo un minuto). Al terzo avvio senza conferma si rimette la versione precedente.
set -u
PATH=/usr/sbin:/usr/bin:/sbin:/bin
umask 077

PROVA=0
[ "${EPT_PROVA:-}" = 1 ] && PROVA=1
# solo per le prove (EPT_PROVA=1) le cartelle si possono cambiare dall'ambiente
if [ "$PROVA" != 1 ] || [ -z "${DIR:-}" ]; then DIR=/opt/easyptt-talk; fi
if [ "$PROVA" != 1 ] || [ -z "${BKDIR:-}" ]; then BKDIR=/var/backups/easyptt-talk; fi
U="$DIR/dati/aggiornamento"
BIN="$DIR/easyptt-talk-server"
T=""

log() { echo "aggiornamento: $*"; }
own() { [ "$PROVA" = 1 ] || chown easyptt:easyptt "$@"; }
rown() { [ "$PROVA" = 1 ] || chown root:root "$@"; } # programma e cartella: di root
# file della cartella dati (scrivibile dal servizio): mai seguire collegamenti simbolici
regular() { [ -f "$1" ] && [ ! -L "$1" ]; }
# scrive un file nella cartella dati senza seguire collegamenti (noclobber = apertura esclusiva)
put() {
  rm -f "$1"
  if (set -C; printf '%s\n' "$2" > "$1") 2>/dev/null; then own "$1"; chmod 600 "$1"; fi
}
esito() {
  rm -f "$U/esito-avvisato"
  put "$U/esito" "$1"
  log "$1"
}
pulisci() { rm -f "$U/pronto" "$U/pacchetto.tar.gz" "$U/pacchetto.sig"; }
fine() { [ -n "$T" ] && rm -rf "$T"; exit 0; }
trap fine EXIT

{ [ -d "$U" ] && [ ! -L "$U" ] && [ ! -L "$DIR/dati" ]; } || exit 0

# ---- versione nuova in prova ----
if regular "$U/provando"; then
  n=$(head -c 10 "$U/provando" | tr -cd 0-9)
  n=$((10#${n:-1} + 1))
  if [ "$n" -ge 3 ]; then
    if regular "$BIN.old" && install -m 755 "$BIN.old" "$BIN.nuovo" && mv -f "$BIN.nuovo" "$BIN"; then
      rown "$BIN"
      # LEGGIMI (versione installata) e dati come prima dell'aggiornamento: la versione precedente
      # non conosce i campi nuovi e al primo salvataggio li perderebbe
      if regular "$BKDIR/leggimi.old"; then
        install -m 644 "$BKDIR/leggimi.old" "$DIR/.LEGGIMI.txt.nuovo" && mv -f "$DIR/.LEGGIMI.txt.nuovo" "$DIR/LEGGIMI.txt"
      fi
      PB=$(head -c 300 "$U/backup-prova" 2>/dev/null)
      case "$PB" in "$BKDIR"/prima-aggiornamento-*.tar.gz)
        T=$(mktemp -d /tmp/easyptt-ritorno.XXXXXX) || T=""
        if [ -n "$T" ] && [ -f "$PB" ] && tar xzf "$PB" -C "$T" dati/dati.json --no-same-owner 2>/dev/null && regular "$T/dati/dati.json" && [ -s "$T/dati/dati.json" ]; then
          install -m 600 "$T/dati/dati.json" "$DIR/dati/.dati.json.nuovo" && own "$DIR/dati/.dati.json.nuovo" && mv -f "$DIR/dati/.dati.json.nuovo" "$DIR/dati/dati.json"
          log "dati ripristinati da $PB"
        fi ;;
      esac
      # la versione fallita non si riprova da sola ogni notte
      [ -n "$(head -c 20 "$U/versione-prova" 2>/dev/null | tr -cd '0-9.')" ] && put "$U/fallita" "$(head -c 20 "$U/versione-prova" | tr -cd '0-9.')"
      esito "Aggiornamento non riuscito: ripristinata la versione precedente"
    else
      esito "Aggiornamento non riuscito e versione precedente non disponibile: reinstalla con installa.sh"
    fi
    rm -f "$U/provando" "$BKDIR/leggimi.old" "$U/backup-prova" "$U/versione-prova"
  else
    log "avvio $n della versione nuova in prova"
    put "$U/provando" "$n"
  fi
fi

# ---- pacchetto pronto da installare ----
if [ -e "$U/pronto" ] || [ -e "$U/pacchetto.tar.gz" ] || [ -e "$U/pacchetto.sig" ]; then
  if ! { regular "$U/pronto" && regular "$U/pacchetto.tar.gz" && regular "$U/pacchetto.sig"; }; then
    log "pacchetto incompleto: scartato"
    pulisci
    exit 0
  fi
  VER=$(head -c 20 "$U/pronto" | tr -cd '0-9.')
  T=$(mktemp -d /tmp/easyptt-aggiornamento.XXXXXX) || { log "cartella temporanea non disponibile"; exit 0; }
  # si lavora su una copia fuori dalla cartella dati: il pacchetto verificato e' quello installato
  cp "$U/pacchetto.tar.gz" "$T/p.tar.gz" && cp "$U/pacchetto.sig" "$T/p.sig" || { log "copia del pacchetto non riuscita"; pulisci; exit 0; }
  pulisci
  if ! "$BIN" -verifica-aggiornamento "$T/p.tar.gz" "$T/p.sig" >/dev/null 2>&1; then
    esito "Firma non valida: aggiornamento scartato"
    exit 0
  fi
  log "firma valida, versione $VER"
  mkdir -p "$T/x" && tar xzf "$T/p.tar.gz" -C "$T/x" --no-same-owner --no-same-permissions 2>/dev/null
  N="$T/x/easyptt-talk-linux"
  if [ ! -f "$N/easyptt-talk-server" ] || [ "$(head -c 4 "$N/easyptt-talk-server" | od -An -c | tr -d ' \n')" != '177ELF' ]; then
    esito "Pacchetto non valido: aggiornamento scartato"
    exit 0
  fi
  # versione scritta nel pacchetto firmato (non quella del file "pronto"): mai una versione piu' vecchia
  NV=$(grep -o 'SERVER [0-9]*\.[0-9]*\.[0-9]*' "$N/LEGGIMI.txt" 2>/dev/null | head -1 | cut -d' ' -f2)
  CV=$(grep -o 'SERVER [0-9]*\.[0-9]*\.[0-9]*' "$DIR/LEGGIMI.txt" 2>/dev/null | head -1 | cut -d' ' -f2)
  if [ -z "$NV" ] || { [ -n "$CV" ] && [ "$(printf '%s\n%s\n' "$CV" "$NV" | sort -V | tail -1)" != "$NV" ]; } || [ "$NV" = "$CV" ]; then
    esito "Pacchetto della versione ${NV:-sconosciuta}, non piu' recente di ${CV:-quella installata}: aggiornamento scartato"
    exit 0
  fi
  VER=$NV
  # backup dei dati (stesse esclusioni del backup giornaliero; senza il pacchetto scaricato)
  mkdir -p "$BKDIR" && chmod 700 "$BKDIR"
  B="$BKDIR/prima-aggiornamento-$(date +%F-%H%M%S).tar.gz"
  if ! tar czf "$B" --exclude='*.ept' --exclude='chiave.key' --exclude='dati/aggiornamento' -C "$DIR" dati 2>/dev/null; then
    rm -f "$B"
    esito "Backup dei dati non riuscito (disco pieno?): aggiornamento non applicato"
    exit 0
  fi
  chmod 600 "$B"
  log "backup dei dati: $B"
  find "$BKDIR" -name 'prima-aggiornamento-*.tar.gz' -mtime +90 -delete 2>/dev/null
  # versione attuale in .old, poi la nuova al suo posto (rinomina: mai un programma a meta')
  if ! { install -m 755 "$BIN" "$BIN.old" && install -m 755 "$N/easyptt-talk-server" "$BIN.nuovo" && mv -f "$BIN.nuovo" "$BIN"; }; then
    rm -f "$BIN.nuovo"
    esito "Installazione non riuscita: resta la versione attuale"
    exit 0
  fi
  rown "$BIN" "$BIN.old" "$DIR"
  # per un eventuale ritorno alla versione precedente
  regular "$DIR/LEGGIMI.txt" && install -m 600 "$DIR/LEGGIMI.txt" "$BKDIR/leggimi.old"
  put "$U/backup-prova" "$B"
  put "$U/versione-prova" "$VER"
  for f in installa.sh certificato.sh sicurezza.sh LEGGIMI.txt applica-aggiornamento.sh; do
    [ -f "$N/$f" ] || continue
    m=755; [ "$f" = LEGGIMI.txt ] && m=644
    install -m "$m" "$N/$f" "$DIR/.$f.nuovo" && mv -f "$DIR/.$f.nuovo" "$DIR/$f"
  done
  put "$U/provando" 1
  log "installata la versione $VER (la precedente e' in $BIN.old)"
fi
exit 0
