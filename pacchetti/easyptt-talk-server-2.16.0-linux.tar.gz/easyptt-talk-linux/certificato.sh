#!/bin/bash
# Certificato HTTPS valido per il nome del server (Let's Encrypt: gratuito, rinnovo automatico).
# Con il certificato: niente avvisi nel browser, indirizzo https://nome (porta 443) e verifica
# completa del server anche dalle radio (app 1.10.0 o successive, configurate con il nome).
#
# PRIMA: nel pannello DNS del dominio crea un record di tipo A che punta a questo server,
#        es. nome "talk" -> 141.227.156.101  (diventa talk.tuodominio.it)
# Uso:   sudo bash certificato.sh talk.tuodominio.it [email per gli avvisi di scadenza]
set -e
[ "$(id -u)" = 0 ] || { echo "Esegui con: sudo bash certificato.sh talk.tuodominio.it"; exit 1; }
D=$(echo "$1" | tr 'A-Z' 'a-z'); MAIL="$2"
if ! [[ "$D" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]]; then
  echo "Uso: sudo bash certificato.sh talk.tuodominio.it [email]"; exit 1
fi
DIR=/opt/easyptt-talk; ETC=/etc/easyptt-talk
[ -x "$DIR/easyptt-talk-server" ] || { echo "Installa prima EasyPTT Talk (sudo bash installa.sh)"; exit 1; }

# IP pubblico: chiesto fuori (il server puo' essere dietro NAT, come su molti cloud: lo vede solo l'IP interno)
IP=""
for u in https://api.ipify.org https://ifconfig.me/ip https://icanhazip.com; do
  IP=$(curl -4 -fsS --max-time 5 "$u" 2>/dev/null | tr -d '[:space:]')
  [[ "$IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && break
  IP=""
done
DNS=$(getent ahostsv4 "$D" | awk 'NR==1{print $1}')
if [ -z "$DNS" ]; then
  echo "Il nome $D non esiste ancora nel DNS."
  echo "Nel pannello DNS del dominio crea un record di tipo A:"
  echo "    nome: ${D%%.*}     tipo: A     valore: ${IP:-<IP pubblico del server>}"
  echo "Poi attendi qualche minuto (a volte fino a un'ora) e rilancia questo comando."
  exit 1
fi
if [ -n "$IP" ] && [ "$DNS" != "$IP" ]; then
  echo "Il nome $D punta a $DNS, ma questo server ha l'indirizzo pubblico $IP."
  echo "Nel pannello DNS correggi il record A:  nome: ${D%%.*}   tipo: A   valore: $IP"
  echo "Poi attendi qualche minuto e rilancia questo comando."
  exit 1
fi
[ -z "$IP" ] && echo "IP pubblico non rilevato (server dietro NAT?): proseguo, il nome punta a $DNS. Let's Encrypt verifica da sola."
# Let's Encrypt deve essere raggiungibile in uscita
if ! curl -fsS --max-time 10 -o /dev/null https://acme-v02.api.letsencrypt.org/directory; then
  echo "Il server non raggiunge Let's Encrypt (acme-v02.api.letsencrypt.org) in uscita."
  echo "Nel firewall del provider consenti il traffico in USCITA (almeno HTTPS, porta 443) e rilancia."
  exit 1
fi

echo "== 1/3 Installo certbot (Let's Encrypt)"
export DEBIAN_FRONTEND=noninteractive
if ! command -v certbot >/dev/null; then
  apt-get update -q >/dev/null; apt-get install -y -q certbot >/dev/null || snap install --classic certbot
fi
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow 80/tcp >/dev/null   # Let's Encrypt verifica il nome su questa porta (anche per i rinnovi)
  ufw allow 443/tcp >/dev/null
fi

# a ogni rinnovo il certificato viene copiato a EasyPTT Talk, che lo ricarica da solo (senza riavvio)
mkdir -p /etc/letsencrypt/renewal-hooks/deploy
HOOK=/etc/letsencrypt/renewal-hooks/deploy/easyptt-talk.sh
cat > "$HOOK" <<H
#!/bin/sh
L=\${RENEWED_LINEAGE:-/etc/letsencrypt/live/$D}
case "\$L" in */$D) ;; *) exit 0 ;; esac
install -o easyptt -g easyptt -m 600 "\$L/privkey.pem" $DIR/dati/dominio.key.tmp && mv -f $DIR/dati/dominio.key.tmp $DIR/dati/dominio.key
install -o easyptt -g easyptt -m 600 "\$L/fullchain.pem" $DIR/dati/dominio.crt.tmp && mv -f $DIR/dati/dominio.crt.tmp $DIR/dati/dominio.crt
H
chmod 755 "$HOOK"

echo "== 2/3 Richiedo il certificato per $D"
if [ -n "$MAIL" ]; then ACC="-m $MAIL"; else ACC="--register-unsafely-without-email"; fi
certbot certonly --standalone --preferred-challenges http -d "$D" --agree-tos --non-interactive \
  --keep-until-expiring $ACC
RENEWED_LINEAGE=/etc/letsencrypt/live/$D sh "$HOOK"

echo "== 3/3 Attivo la porta 443 e il nome"
mkdir -p "$ETC"
echo "$D" > "$ETC/dominio"
if ss -ltnp 2>/dev/null | grep -E ":443 " | grep -vq easyptt; then
  echo "La porta 443 e' gia' usata da un altro programma: EasyPTT Talk resta su https://$D:8443"
  : > "$ETC/opzioni"
else
  echo 'EPT_OPZIONI="-https :8443,:443"' > "$ETC/opzioni"
fi
systemctl restart easyptt-talk
sleep 3
systemctl is-active --quiet easyptt-talk && echo "EasyPTT Talk: in funzione" || { echo "ATTENZIONE: il servizio non e' partito"; journalctl -u easyptt-talk -n 10 --no-pager; exit 1; }
P=""; grep -q ":443" "$ETC/opzioni" || P=":8443"
echo
echo "Fatto. Certificato valido fino al $(openssl x509 -enddate -noout -in $DIR/dati/dominio.crt | cut -d= -f2) (si rinnova da solo)."
echo "  Console:   https://$D$P"
echo "  Centrale:  https://$D$P/centrale"
PORT=${P#:}; [ -n "$PORT" ] || PORT=443
echo "  Radio:     server $D, porta $PORT  (app 1.10.0 o successiva; le radio con l'indirizzo IP continuano a funzionare)"
