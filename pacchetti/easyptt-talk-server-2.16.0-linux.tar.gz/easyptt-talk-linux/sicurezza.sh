#!/bin/bash
# Messa in sicurezza del VPS di EasyPTT Talk (Ubuntu/Debian).
# Uso: sudo bash sicurezza.sh
# Fa: aggiornamenti di sistema (anche automatici), firewall con solo le porte 22, 8443 e quelle dei droni DJI,
# blocco dei tentativi di accesso ripetuti, accesso SSH solo con chiave.
set -e
[ "$(id -u)" = 0 ] || { echo "Esegui con: sudo bash sicurezza.sh"; exit 1; }

U=${SUDO_USER:-ubuntu}
H=$(getent passwd "$U" | cut -d: -f6)
AK="$H/.ssh/authorized_keys"
if [ ! -s "$AK" ]; then
  echo "ERRORE: nessuna chiave SSH per l'utente $U ($AK)."
  echo "Prima aggiungi la chiave del tuo PC (vedi istruzioni), poi rilancia. Non ho cambiato nulla."
  exit 1
fi

echo; echo "== 1/4 Aggiornamenti di sistema (qualche minuto)"
export DEBIAN_FRONTEND=noninteractive
APT="-y -q -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold"
apt-get update -q
apt-get $APT upgrade
apt-get $APT install ufw fail2ban unattended-upgrades python3-systemd
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
EOF
echo "Aggiornamenti di sicurezza automatici: attivi"

echo; echo "== 2/4 Firewall: aperte solo SSH (22) e EasyPTT Talk (8443; droni DJI 8090, 1883, 1935)"
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow 22/tcp >/dev/null
ufw allow 8443/tcp >/dev/null
for p in 8090 1883 1935; do ufw allow $p/tcp >/dev/null; done
# certificato del dominio (certificato.sh): 80 per Let's Encrypt, 443 per console e centrale
if [ -s /etc/easyptt-talk/dominio ]; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; fi
ufw --force enable

echo; echo "== 3/4 Blocco dei tentativi di accesso ripetuti (fail2ban)"
cat > /etc/fail2ban/jail.d/easyptt.conf <<'EOF'
[sshd]
enabled = true
backend = systemd
maxretry = 5
bantime = 1h
EOF
if systemctl enable fail2ban >/dev/null 2>&1 && systemctl restart fail2ban; then
  echo "fail2ban: attivo"
else
  echo "fail2ban non si e' avviato (non indispensabile, il resto e' attivo)"
fi

echo; echo "== 4/4 SSH: solo con chiave, niente password, niente accesso diretto di root"
CONF=/etc/ssh/sshd_config.d/00-easyptt.conf
cat > "$CONF" <<'EOF'
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin no
EOF
if ! sshd -t 2>/dev/null; then
  rm -f "$CONF"
  echo "Configurazione SSH non valida: lasciata com'era (accesso con password ancora attivo)"
else
  systemctl reload ssh 2>/dev/null || systemctl reload sshd
  echo "SSH: accesso solo con chiave"
fi

echo; echo "== Fatto"
ufw status | sed -n '1,12p'
systemctl is-active --quiet easyptt-talk && echo "EasyPTT Talk: in funzione" || echo "ATTENZIONE: EasyPTT Talk non risulta attivo"
if [ -f /var/run/reboot-required ]; then
  echo
  echo "Serve un riavvio per completare gli aggiornamenti:  sudo reboot"
  echo "(il server PTT riparte da solo; le radio si ricollegano entro un minuto)"
fi
