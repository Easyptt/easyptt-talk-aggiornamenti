@echo off
cd /d "%~dp0"
easyptt-archivio.exe installa
if errorlevel 1 (echo. & echo Avvia con tasto destro ^> Esegui come amministratore) else (start http://127.0.0.1:8095)
pause
