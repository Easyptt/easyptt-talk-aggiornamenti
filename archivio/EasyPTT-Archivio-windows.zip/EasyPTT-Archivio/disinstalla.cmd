@echo off
cd /d "%~dp0"
easyptt-archivio.exe disinstalla
pause
